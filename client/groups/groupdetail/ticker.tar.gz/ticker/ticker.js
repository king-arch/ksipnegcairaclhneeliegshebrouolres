
import { Template } from 'meteor/templating';
import { Base64 } from 'meteor/ostrio:base64';
import { FriendRequest }  from './../../import/collections/insert.js';
import { UserInfo } from './../../import/collections/insert.js';
import { Emembers } from './../../import/collections/insert.js';
import { Event } from './../../import/collections/insert.js';
import { advertisement } from './../../import/collections/insert.js';

import { Session } from 'meteor/session';
import { ReactiveVar } from 'meteor/reactive-var';

Template.ticker.onRendered(function(){
function tick() {
    $('#ticker li:first').slideUp(function() {
        $(this).appendTo($('#ticker')).slideDown();
    });
}
setInterval(function() {
    tick()
}, 5000);	
});

Template.picture_ticker.onRendered(function(){
function tick2() {
    $('#ticker2 li:first').slideUp(function() {
        $(this).appendTo($('#ticker2')).slideDown();
    });
}
setInterval(function() {
    tick2()
}, 5000);	
});

Template.ticker.helpers({

	change_textual_ads(){
    var result = advertisement.find({ads_type: 'Textual',is_active: {$ne: 'Inactive'} }).fetch();
    return result;
	},

});

	function tick() {
    $('#ticker li:first').slideUp(function() {
        $(this).appendTo($('#ticker')).slideDown();
    });
}

Template.picture_ticker.helpers({
	change_picture_ads(){
    var result = advertisement.find({ads_type: 'Picture',is_active: {$ne: 'Inactive'} }).fetch();
    return result;

	},

});

	function tick2() {
    $('#ticker li:first').slideUp(function() {
        $(this).appendTo($('#ticker')).slideDown();
    });
}